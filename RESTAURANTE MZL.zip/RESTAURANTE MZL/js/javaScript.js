document.getElementById("ocultar").style.display='none';
function enviar(){
    document.getElementById("ocultar").style.display='block';
    let nom= document.getElementById("nombre").value;
    let fec= document.getElementById("fecha").value;
    let hor= document.getElementById("hora").value;

    //alert("Señor@: "+nom+" Su reserva es para la fecha: "+fec+" A las: "+hor);
    if(hor<"21:00"){
        alert("Reserva realizada")
    document.getElementById("mostrarNom").innerHTML=nom;
    document.getElementById("mostrarFec").innerHTML=fec;
    document.getElementById("mostrarHor").innerHTML=hor;
    }
    else{
        alert("no fue realizada")
    }
}

function cambiar(){
    document.getElementById("plato1").src="../img/ScriptArrozCamarones.png";
    document.getElementById("plato2").src="../img/PlatoMaritimo.png";
    document.getElementById("plato3").src="../img/BandejaPaisa.png";
}

function cambiar2(){
    document.getElementById("plato1").src="https://i0.wp.com/ellatinoonline.com/wp-content/uploads/2022/02/paella.jpg?w=1200&ssl=1";
    document.getElementById("plato2").src="https://www.recetasnestle.com.co/sites/default/files/styles/crop_article_banner_desktop_nes/public/2022-06/ingredientes-comida-de-mar-parrilla.webp?itok=TF4mu2pM";
    document.getElementById("plato3").src="https://www.viajabonito.mx/wp-content/uploads/2021/06/Comida-colombiana-portada-01.jpg";
}
